BETZONE — VERSION 1.0
====================

Contenu :
- index.html : structure du site
- style.css : design responsive vert/noir
- app.js : navigation, quiz, points fictifs, boutique cosmétique démo

Lancer en local :
1. Décompressez betzone.zip.
2. Ouvrez index.html dans un navigateur moderne.

Publication :
- Déposez ces trois fichiers dans un dépôt GitHub.
- Activez GitHub Pages dans Settings > Pages, source "Deploy from a branch", branche main, dossier /root.
- Vous obtiendrez une adresse publique en sous-domaine github.io.

Limites importantes :
- Cette version est une démonstration front-end : données enregistrées localement dans le navigateur.
- Pas de comptes sécurisés, classement partagé, données sportives en direct, publicité réelle ou paiement.
- Le classement est fictif.
- Les emplacements publicitaires sont des placeholders.
- Les points n'ont aucune valeur monétaire et ne sont pas convertibles.
- Avant une ouverture publique, ajoutez modération, politique de confidentialité, mentions légales, sécurité serveur et conformité aux règles applicables.
- N'ajoutez pas de paris payants, de dépôts/retraits ou de récompenses monétaires liées au hasard.
