const STORE_KEY = "betzone_demo_v1";
const defaultState = { points: 500, completed: 0, unlocked: [] };
let state = loadState();
const quiz = [
  { q:"Quel pays a remporté la Coupe du monde masculine 2018 ?", a:["France","Croatie","Brésil","Allemagne"], correct:0, explain:"La France a remporté la finale 4–2 contre la Croatie." },
  { q:"Combien de joueurs une équipe de football aligne-t-elle au coup d'envoi ?", a:["9","10","11","12"], correct:2, explain:"Une équipe aligne normalement 11 joueurs, gardien compris." },
  { q:"Sur quelle surface se joue traditionnellement Roland-Garros ?", a:["Gazon","Terre battue","Béton","Bois"], correct:1, explain:"Roland-Garros se joue sur terre battue." },
  { q:"Combien vaut un panier réussi derrière la ligne à trois points au basket ?", a:["1 point","2 points","3 points","4 points"], correct:2, explain:"Un tir réussi derrière la ligne vaut 3 points." },
  { q:"Dans quel sport utilise-t-on un volant ?", a:["Badminton","Tennis","Squash","Volley"], correct:0, explain:"Le badminton se joue avec un volant." }
];
let questionIndex = 0, answered = false;
function loadState(){ try { return {...defaultState,...JSON.parse(localStorage.getItem(STORE_KEY)||"{}")}; } catch { return {...defaultState}; } }
function saveState(){ localStorage.setItem(STORE_KEY, JSON.stringify(state)); renderStats(); }
function renderStats(){
  ["header-points","hero-points","stat-points"].forEach(id=>{const el=document.getElementById(id);if(el)el.textContent=state.points.toLocaleString("fr-FR");});
  document.getElementById("stat-done").textContent=state.completed;
  const level=Math.floor(state.points/1000)+1;
  document.getElementById("stat-level").textContent=level;
  document.getElementById("leader-you").textContent=state.points.toLocaleString("fr-FR")+" pts";
  const progress=state.points%1000;
  document.getElementById("progress-fill").style.width=(progress/10)+"%";
  document.getElementById("progress-label").textContent=`Encore ${1000-progress} points pour le niveau suivant`;
}
function showToast(msg){const t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2300);}
function go(page){
  document.querySelectorAll(".page").forEach(p=>p.classList.toggle("active",p.id==="page-"+page));
  document.querySelectorAll(".nav-btn").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
  window.scrollTo({top:0,behavior:"smooth"});
}
document.querySelectorAll("[data-page]").forEach(b=>b.addEventListener("click",()=>go(b.dataset.page)));
document.querySelectorAll("[data-go]").forEach(b=>b.addEventListener("click",()=>go(b.dataset.go)));
function renderQuestion(){
  answered=false;
  const q=quiz[questionIndex];
  document.getElementById("question").textContent=q.q;
  document.getElementById("quiz-feedback").textContent="";
  document.getElementById("next-question").classList.add("hidden");
  const wrap=document.getElementById("answers");wrap.innerHTML="";
  q.a.forEach((answer,i)=>{const btn=document.createElement("button");btn.className="answer";btn.textContent=answer;btn.addEventListener("click",()=>chooseAnswer(i));wrap.appendChild(btn);});
}
function chooseAnswer(i){
  if(answered)return; answered=true;
  const q=quiz[questionIndex], buttons=[...document.querySelectorAll(".answer")];
  buttons.forEach((b,index)=>{b.disabled=true;if(index===q.correct)b.classList.add("correct");else if(index===i)b.classList.add("wrong");});
  const correct=i===q.correct;
  if(correct){state.points+=50;state.completed+=1;saveState();document.getElementById("quiz-feedback").textContent="Bonne réponse ! +50 points. "+q.explain;}
  else {document.getElementById("quiz-feedback").textContent="Pas tout à fait. "+q.explain;}
  document.getElementById("next-question").classList.remove("hidden");
}
document.getElementById("next-question").addEventListener("click",()=>{questionIndex=(questionIndex+1)%quiz.length;renderQuestion();});
document.querySelectorAll(".cosmetic").forEach(btn=>btn.addEventListener("click",()=>{
  const item=btn.dataset.item,cost=Number(btn.dataset.cost);
  if(state.unlocked.includes(item)){showToast("Cet élément est déjà débloqué.");return;}
  if(state.points<cost){showToast("Pas assez de points pour le moment.");return;}
  state.points-=cost;state.unlocked.push(item);saveState();btn.textContent="Débloqué ✓";btn.disabled=true;showToast(item+" débloqué !");
}));
renderStats();renderQuestion();
